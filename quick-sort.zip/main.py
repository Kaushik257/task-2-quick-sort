def partition(arr,first,last): 
    i = ( first-1 )          
    pivot = arr[last]      
  
    for j in range(first , last): 
        if   arr[j] <= pivot:  
            i = i+1 
            arr[i],arr[j] = arr[j],arr[i] 
    arr[i+1],arr[last] = arr[last],arr[i+1] 
    return ( i+1 )  
def quickSort(arr,first,last): 
    if first < last: 
        pi = partition(arr,first,last)  
        quickSort(arr, first, pi-1) 
        quickSort(arr, pi+1, last)  
arr = [90, 76, 82, 9, 11, 51] 
n = len(arr) 
quickSort(arr,0,n-1) 
print ("Sorted array is:") 
for i in range(n): 
    print ("%d" %arr[i]), 